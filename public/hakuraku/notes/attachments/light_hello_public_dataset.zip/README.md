# Light Hello research data

Files:

- `light_hello_proc_trials.jsonl` — Light Hello post-training event observations.
- `facility_appearances.json` — aggregate support placement counts.

Notes:

- Light Hello cannot appear on turns 1–4.
- Her first training always plays the fixed intro event, so those trainings are not in the proc file.
- These runs ended on turn 37 before post-training events resolved. Turn-37 rows are retained with `proc_eligible: false`.
- Filtering to `proc_eligible: true` gives `4068 / 10190 = 39.92%`.
- `run_id` is pseudonymous but still groups observations from the same run.
- In the placement data, Light Hello's `min_turn` is 5.
